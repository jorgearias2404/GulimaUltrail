var story = {
 "docName": "GulimaUltrailAPP",
 "docPath": "P_P_P",
 "docVersion": 100000001,
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "fileType": "png",
 "disableInteractions": false,
 "highlightHotspot": true,
 "highlightAllHotspots": true,
 "hideGallery": false,
 "galleryPageColorsEnabled": true,
 "galleryDecorNodesEnabled": true,
 "zoomEnabled": true,
 "cloud": false,
 "singleFile": false,
 "title": "GulimaUltrailAPP",
 "layersExist": true,
 "pages": [
  {
   "id": "43:7",
   "groupIndex": 0,
   "title": "Gestión de Corredores 1",
   "image": "gestión-de-corredores-1.png",
   "index": 0,
   "width": 1600,
   "height": 900,
   "x": 0,
   "y": 0,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 24,
      "width": 122,
      "height": 22
     },
     "index": 0,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 0,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 24,
      "width": 145,
      "height": 22
     },
     "index": 1,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 0,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 23,
      "width": 117,
      "height": 22
     },
     "index": 2,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 0,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 23,
      "width": 112,
      "height": 24
     },
     "index": 3,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 0,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 23,
      "width": 116,
      "height": 24
     },
     "index": 4,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 0,
       "frameIndex": 0,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "50:2",
   "groupIndex": 0,
   "title": "Orden de Llegada - Absolutos",
   "image": "orden-de-llegada-absolutos.png",
   "index": 1,
   "width": 1600,
   "height": 900,
   "x": 0,
   "y": 1043,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Rectangle 15",
     "rect": {
      "x": 503,
      "y": 179,
      "width": 23,
      "height": 23
     },
     "index": 5,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 5,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Podios",
     "rect": {
      "x": 726,
      "y": 100,
      "width": 103,
      "height": 26
     },
     "index": 6,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Descalificados",
     "rect": {
      "x": 957,
      "y": 98,
      "width": 189,
      "height": 31
     },
     "index": 7,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 10,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 8,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 9,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 10,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 11,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 1,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 12,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 1,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "61:2604",
   "groupIndex": 0,
   "title": "Puntajes - Corredores",
   "image": "puntajes-corredores.png",
   "index": 2,
   "width": 1600,
   "height": 900,
   "x": 0,
   "y": 2086,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 13,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 2,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 14,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 15,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 16,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 17,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Podios",
     "rect": {
      "x": 865,
      "y": 100,
      "width": 96,
      "height": 27
     },
     "index": 18,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 2,
       "frameIndex": 6,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "61:3295",
   "groupIndex": 0,
   "title": "Gestión de Corredores",
   "image": "gestión-de-corredores.png",
   "index": 3,
   "width": 1600,
   "height": 900,
   "x": 0,
   "y": 3129,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Rectangle 15",
     "rect": {
      "x": 86,
      "y": 343,
      "width": 23,
      "height": 23
     },
     "index": 19,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 7,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 20,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 21,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 3,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 22,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 23,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 24,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 3,
       "frameIndex": 0,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "61:3601",
   "groupIndex": 0,
   "title": "Registro de Corredores",
   "image": "registro-de-corredores.png",
   "index": 4,
   "width": 1600,
   "height": 900,
   "x": 1,
   "y": 4172,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 25,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 4,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 26,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 4,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 27,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 4,
       "frameIndex": 4,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 28,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 4,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 29,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 4,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "56:2",
   "groupIndex": 0,
   "title": "Orden de Llegada - Absolutos, Distancia",
   "image": "orden-de-llegada-absolutos-distancia.png",
   "index": 5,
   "width": 1600,
   "height": 900,
   "x": 1640,
   "y": 1043,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Rectangle 15",
     "rect": {
      "x": 503,
      "y": 179,
      "width": 23,
      "height": 23
     },
     "index": 30,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Rectangle 16",
     "rect": {
      "x": 831,
      "y": 179,
      "width": 23,
      "height": 23
     },
     "index": 31,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 8,
       "disableAutoScroll": true,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Podios",
     "rect": {
      "x": 726,
      "y": 100,
      "width": 103,
      "height": 26
     },
     "index": 32,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Descalificados",
     "rect": {
      "x": 957,
      "y": 98,
      "width": 189,
      "height": 31
     },
     "index": 33,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 10,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 34,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 35,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 36,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 37,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 38,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 5,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "61:3083",
   "groupIndex": 0,
   "title": "Puntajes - Clubs",
   "image": "puntajes-clubs.png",
   "index": 6,
   "width": 1600,
   "height": 900,
   "x": 1640,
   "y": 2086,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 39,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 40,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 41,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 42,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 43,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Absolutos",
     "rect": {
      "x": 591,
      "y": 101,
      "width": 150,
      "height": 26
     },
     "index": 44,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 6,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "83:309",
   "groupIndex": 0,
   "title": "Gestión de Corredores - Descalificar",
   "image": "gestión-de-corredores-descalificar.png",
   "index": 7,
   "width": 1600,
   "height": 900,
   "x": 1640,
   "y": 3129,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 45,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 46,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 47,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 48,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 49,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Descalificar btn",
     "rect": {
      "x": 539,
      "y": 645,
      "width": 222,
      "height": 40
     },
     "index": 50,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Cancelar btn",
     "rect": {
      "x": 839,
      "y": 645,
      "width": 222,
      "height": 40
     },
     "index": 51,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 7,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "57:874",
   "groupIndex": 0,
   "title": "Orden de Llegada - Absolutos, Distancia, Sexo",
   "image": "orden-de-llegada-absolutos-distancia-sexo.png",
   "index": 8,
   "width": 1600,
   "height": 900,
   "x": 3280,
   "y": 1043,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Rectangle 15",
     "rect": {
      "x": 831,
      "y": 179,
      "width": 23,
      "height": 23
     },
     "index": 52,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 5,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Podios",
     "rect": {
      "x": 726,
      "y": 100,
      "width": 103,
      "height": 26
     },
     "index": 53,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Descalificados",
     "rect": {
      "x": 957,
      "y": 98,
      "width": 189,
      "height": 31
     },
     "index": 54,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 10,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 55,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 56,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 57,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 58,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 59,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 8,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "58:1387",
   "groupIndex": 0,
   "title": "Orden de Llegada - Podios, Todo",
   "image": "orden-de-llegada-podios-todo.png",
   "index": 9,
   "width": 1600,
   "height": 900,
   "x": 4920,
   "y": 1043,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Absolutos",
     "rect": {
      "x": 452,
      "y": 101,
      "width": 144,
      "height": 28
     },
     "index": 60,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Descalificados",
     "rect": {
      "x": 957,
      "y": 98,
      "width": 189,
      "height": 31
     },
     "index": 61,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 10,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 62,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 63,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 64,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 65,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 66,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 9,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  },
  {
   "id": "61:1754",
   "groupIndex": 0,
   "title": "Orden de Llegada - Descalificados",
   "image": "orden-de-llegada-descalificados.png",
   "index": 10,
   "width": 1600,
   "height": 900,
   "x": 6560,
   "y": 1043,
   "awidth": 1600,
   "aheight": 900,
   "ax": 0,
   "ay": 0,
   "protoOverflowV": false,
   "protoOverflowH": false,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Absolutos",
     "rect": {
      "x": 452,
      "y": 101,
      "width": 144,
      "height": 28
     },
     "index": 67,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Podios",
     "rect": {
      "x": 726,
      "y": 100,
      "width": 103,
      "height": 26
     },
     "index": 68,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 9,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Pts Corredores",
     "rect": {
      "x": 722,
      "y": 23,
      "width": 122,
      "height": 22
     },
     "index": 69,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 2,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Corredores",
     "rect": {
      "x": 981,
      "y": 23,
      "width": 145,
      "height": 22
     },
     "index": 70,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 3,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Registro",
     "rect": {
      "x": 1263,
      "y": 22,
      "width": 117,
      "height": 22
     },
     "index": 71,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 4,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Llegada",
     "rect": {
      "x": 473,
      "y": 22,
      "width": 112,
      "height": 24
     },
     "index": 72,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 1,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    },
    {
     "name": "Carrera",
     "rect": {
      "x": 220,
      "y": 22,
      "width": 116,
      "height": 24
     },
     "index": 73,
     "reactions": [
      {
       "action": "FRAME",
       "navigationType": "NAVIGATE",
       "trigger": "ON_CLICK",
       "srcPageIndex": 10,
       "frameIndex": 0,
       "transAnimType": 0,
       "transAnimDuration": 300,
       "tmpDestModal": false
      }
     ]
    }
   ],
   "layout": null
  }
 ],
 "totalImages": 11,
 "fileKey": "GulimaUltrail APP view",
 "groups": [
  {
   "id": "24:2",
   "index": 0,
   "name": "Operator View",
   "backColor": "#1E1E1E"
  }
 ]
}